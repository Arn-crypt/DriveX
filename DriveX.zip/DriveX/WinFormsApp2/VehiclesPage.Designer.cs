namespace WinFormsApp2;

partial class VehiclesPage
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        lblMake = new Label();
        lblModel = new Label();
        lblYear = new Label();
        lblCategory = new Label();
        lblRate = new Label();
        txtMake = new TextBox();
        txtModel = new TextBox();
        numYear = new NumericUpDown();
        cboCategory = new ComboBox();
        numRate = new NumericUpDown();
        btnAdd = new Button();
        btnUpdate = new Button();
        btnDelete = new Button();
        btnClear = new Button();
        dgvVehicles = new DataGridView();
        ((System.ComponentModel.ISupportInitialize)numYear).BeginInit();
        ((System.ComponentModel.ISupportInitialize)numRate).BeginInit();
        ((System.ComponentModel.ISupportInitialize)dgvVehicles).BeginInit();
        SuspendLayout();
        //
        // lblTitle
        //
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitle.Location = new Point(18, 8);
        lblTitle.Name = "lblTitle";
        lblTitle.Text = "Manage vehicles";
        //
        // field labels
        //
        SetLabel(lblMake, "lblMake", "Make", 20);
        SetLabel(lblModel, "lblModel", "Model", 190);
        SetLabel(lblYear, "lblYear", "Year", 360);
        SetLabel(lblCategory, "lblCategory", "Category", 450);
        SetLabel(lblRate, "lblRate", "Daily rate (\u20B1)", 600);
        //
        // txtMake
        //
        txtMake.Font = new Font("Segoe UI", 10F);
        txtMake.Location = new Point(20, 68);
        txtMake.Name = "txtMake";
        txtMake.Size = new Size(160, 25);
        txtMake.TabIndex = 0;
        //
        // txtModel
        //
        txtModel.Font = new Font("Segoe UI", 10F);
        txtModel.Location = new Point(190, 68);
        txtModel.Name = "txtModel";
        txtModel.Size = new Size(160, 25);
        txtModel.TabIndex = 1;
        //
        // numYear
        //
        numYear.Font = new Font("Segoe UI", 10F);
        numYear.Location = new Point(360, 68);
        numYear.Maximum = 2100;
        numYear.Minimum = 1990;
        numYear.Name = "numYear";
        numYear.Size = new Size(80, 25);
        numYear.TabIndex = 2;
        numYear.Value = 2024;
        //
        // cboCategory
        //
        cboCategory.DropDownStyle = ComboBoxStyle.DropDownList;
        cboCategory.Font = new Font("Segoe UI", 10F);
        cboCategory.Location = new Point(450, 68);
        cboCategory.Name = "cboCategory";
        cboCategory.Size = new Size(140, 25);
        cboCategory.TabIndex = 3;
        //
        // numRate
        //
        numRate.DecimalPlaces = 2;
        numRate.Font = new Font("Segoe UI", 10F);
        numRate.Increment = 100;
        numRate.Location = new Point(600, 68);
        numRate.Maximum = 1000000;
        numRate.Name = "numRate";
        numRate.Size = new Size(130, 25);
        numRate.TabIndex = 4;
        numRate.ThousandsSeparator = true;
        numRate.Value = 1000;
        //
        // buttons
        //
        StyleButton(btnAdd, "btnAdd", "Add", 20, true, 5);
        btnAdd.Click += btnAdd_Click;
        StyleButton(btnUpdate, "btnUpdate", "Update", 130, false, 6);
        btnUpdate.Click += btnUpdate_Click;
        StyleButton(btnDelete, "btnDelete", "Delete", 240, false, 7);
        btnDelete.Click += btnDelete_Click;
        StyleButton(btnClear, "btnClear", "Clear", 350, false, 8);
        btnClear.Click += btnClear_Click;
        //
        // dgvVehicles
        //
        dgvVehicles.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvVehicles.Location = new Point(20, 150);
        dgvVehicles.Name = "dgvVehicles";
        dgvVehicles.Size = new Size(840, 260);
        dgvVehicles.TabIndex = 9;
        dgvVehicles.SelectionChanged += dgvVehicles_SelectionChanged;
        //
        // VehiclesPage
        //
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.White;
        Controls.Add(dgvVehicles);
        Controls.Add(btnClear);
        Controls.Add(btnDelete);
        Controls.Add(btnUpdate);
        Controls.Add(btnAdd);
        Controls.Add(numRate);
        Controls.Add(cboCategory);
        Controls.Add(numYear);
        Controls.Add(txtModel);
        Controls.Add(txtMake);
        Controls.Add(lblRate);
        Controls.Add(lblCategory);
        Controls.Add(lblYear);
        Controls.Add(lblModel);
        Controls.Add(lblMake);
        Controls.Add(lblTitle);
        Name = "VehiclesPage";
        Size = new Size(880, 428);
        ((System.ComponentModel.ISupportInitialize)numYear).EndInit();
        ((System.ComponentModel.ISupportInitialize)numRate).EndInit();
        ((System.ComponentModel.ISupportInitialize)dgvVehicles).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private static void SetLabel(Label l, string name, string text, int x)
    {
        l.AutoSize = true;
        l.Font = new Font("Segoe UI", 9F);
        l.Location = new Point(x, 48);
        l.Name = name;
        l.Text = text;
    }

    private static void StyleButton(Button b, string name, string text, int x, bool primary, int tab)
    {
        b.BackColor = primary ? Color.Black : Color.White;
        b.ForeColor = primary ? Color.White : Color.Black;
        b.FlatAppearance.BorderColor = Color.Black;
        b.FlatStyle = FlatStyle.Flat;
        b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        b.Location = new Point(x, 104);
        b.Name = name;
        b.Size = new Size(100, 32);
        b.TabIndex = tab;
        b.Text = text;
        b.UseVisualStyleBackColor = false;
    }

    private Label lblTitle;
    private Label lblMake;
    private Label lblModel;
    private Label lblYear;
    private Label lblCategory;
    private Label lblRate;
    private TextBox txtMake;
    private TextBox txtModel;
    private NumericUpDown numYear;
    private ComboBox cboCategory;
    private NumericUpDown numRate;
    private Button btnAdd;
    private Button btnUpdate;
    private Button btnDelete;
    private Button btnClear;
    private DataGridView dgvVehicles;
}
