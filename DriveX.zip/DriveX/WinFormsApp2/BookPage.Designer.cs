namespace WinFormsApp2;

partial class BookPage
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        lblVehicle = new Label();
        lblName = new Label();
        lblPhone = new Label();
        lblStart = new Label();
        lblEnd = new Label();
        cboVehicle = new ComboBox();
        txtName = new TextBox();
        txtPhone = new TextBox();
        dtpStart = new DateTimePicker();
        dtpEnd = new DateTimePicker();
        lblSummary = new Label();
        btnBook = new Button();
        SuspendLayout();
        //
        // lblTitle
        //
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitle.Location = new Point(18, 8);
        lblTitle.Name = "lblTitle";
        lblTitle.Text = "Book a car";
        //
        // labels
        //
        SetLabel(lblVehicle, "lblVehicle", "Vehicle", 20, 50);
        SetLabel(lblName, "lblName", "Customer name", 20, 105);
        SetLabel(lblPhone, "lblPhone", "Phone (optional)", 20, 160);
        SetLabel(lblStart, "lblStart", "Start date", 20, 215);
        SetLabel(lblEnd, "lblEnd", "Return date", 220, 215);
        //
        // cboVehicle
        //
        cboVehicle.DropDownStyle = ComboBoxStyle.DropDownList;
        cboVehicle.Font = new Font("Segoe UI", 10F);
        cboVehicle.Location = new Point(20, 72);
        cboVehicle.Name = "cboVehicle";
        cboVehicle.Size = new Size(380, 25);
        cboVehicle.TabIndex = 0;
        cboVehicle.SelectedIndexChanged += Input_Changed;
        //
        // txtName
        //
        txtName.Font = new Font("Segoe UI", 10F);
        txtName.Location = new Point(20, 127);
        txtName.MaxLength = 100;
        txtName.Name = "txtName";
        txtName.Size = new Size(380, 25);
        txtName.TabIndex = 1;
        //
        // txtPhone
        //
        txtPhone.Font = new Font("Segoe UI", 10F);
        txtPhone.Location = new Point(20, 182);
        txtPhone.MaxLength = 30;
        txtPhone.Name = "txtPhone";
        txtPhone.Size = new Size(380, 25);
        txtPhone.TabIndex = 2;
        //
        // dtpStart
        //
        dtpStart.Font = new Font("Segoe UI", 10F);
        dtpStart.Format = DateTimePickerFormat.Short;
        dtpStart.Location = new Point(20, 237);
        dtpStart.Name = "dtpStart";
        dtpStart.Size = new Size(180, 25);
        dtpStart.TabIndex = 3;
        dtpStart.ValueChanged += Input_Changed;
        //
        // dtpEnd
        //
        dtpEnd.Font = new Font("Segoe UI", 10F);
        dtpEnd.Format = DateTimePickerFormat.Short;
        dtpEnd.Location = new Point(220, 237);
        dtpEnd.Name = "dtpEnd";
        dtpEnd.Size = new Size(180, 25);
        dtpEnd.TabIndex = 4;
        dtpEnd.ValueChanged += Input_Changed;
        //
        // lblSummary
        //
        lblSummary.BackColor = Color.WhiteSmoke;
        lblSummary.BorderStyle = BorderStyle.FixedSingle;
        lblSummary.Font = new Font("Segoe UI", 13F, FontStyle.Bold);
        lblSummary.Location = new Point(460, 72);
        lblSummary.Name = "lblSummary";
        lblSummary.Padding = new Padding(14);
        lblSummary.Size = new Size(390, 190);
        //
        // btnBook
        //
        btnBook.BackColor = Color.Black;
        btnBook.FlatStyle = FlatStyle.Flat;
        btnBook.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        btnBook.ForeColor = Color.White;
        btnBook.Location = new Point(20, 295);
        btnBook.Name = "btnBook";
        btnBook.Size = new Size(380, 42);
        btnBook.TabIndex = 5;
        btnBook.Text = "Confirm booking";
        btnBook.UseVisualStyleBackColor = false;
        btnBook.Click += btnBook_Click;
        //
        // BookPage
        //
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.White;
        Controls.Add(btnBook);
        Controls.Add(lblSummary);
        Controls.Add(dtpEnd);
        Controls.Add(dtpStart);
        Controls.Add(txtPhone);
        Controls.Add(txtName);
        Controls.Add(cboVehicle);
        Controls.Add(lblEnd);
        Controls.Add(lblStart);
        Controls.Add(lblPhone);
        Controls.Add(lblName);
        Controls.Add(lblVehicle);
        Controls.Add(lblTitle);
        Name = "BookPage";
        Size = new Size(880, 428);
        ResumeLayout(false);
        PerformLayout();
    }

    private static void SetLabel(Label l, string name, string text, int x, int y)
    {
        l.AutoSize = true;
        l.Font = new Font("Segoe UI", 9F);
        l.Location = new Point(x, y);
        l.Name = name;
        l.Text = text;
    }

    private Label lblTitle;
    private Label lblVehicle;
    private Label lblName;
    private Label lblPhone;
    private Label lblStart;
    private Label lblEnd;
    private ComboBox cboVehicle;
    private TextBox txtName;
    private TextBox txtPhone;
    private DateTimePicker dtpStart;
    private DateTimePicker dtpEnd;
    private Label lblSummary;
    private Button btnBook;
}
