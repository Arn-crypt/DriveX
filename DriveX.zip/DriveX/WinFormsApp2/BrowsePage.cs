namespace WinFormsApp2;

public partial class BrowsePage : UserControl
{
    private readonly Form1 _host;

    public BrowsePage(Form1 host)
    {
        _host = host;
        InitializeComponent();
        Ui.StyleGrid(dgvCars);
        cboCategory.Items.Add("All");
        cboCategory.Items.AddRange(Ui.Categories);
        cboCategory.SelectedIndex = 0;
        LoadCars();
    }

    private void LoadCars()
    {
        var dt = Db.Query(@"
SELECT Id, Make, Model, [Year], Category, DailyRate AS [Daily Rate]
FROM dbo.Vehicles
WHERE IsRented = 0
  AND (Make + ' ' + Model) LIKE @s
  AND (@c = 'All' OR Category = @c)
ORDER BY Make, Model",
            Db.P("@s", "%" + txtSearch.Text.Trim() + "%"),
            Db.P("@c", cboCategory.Text));

        dgvCars.DataSource = dt;
        dgvCars.Columns["Id"].Visible = false;
        Ui.MoneyColumn(dgvCars, "Daily Rate");
        lblCount.Text = dt.Rows.Count + " available";
    }

    private void Filter_Changed(object sender, EventArgs e) => LoadCars();

    private void btnBook_Click(object sender, EventArgs e)
    {
        if (dgvCars.CurrentRow == null)
        {
            Ui.Warn("Select a car first.");
            return;
        }
        _host.ShowBook((int)dgvCars.CurrentRow.Cells["Id"].Value);
    }
}
