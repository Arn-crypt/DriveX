namespace WinFormsApp2;

static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();
        try
        {
            Db.Init();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not connect to SQL Server.\n\n" + ex.Message +
                "\n\nCheck the connection string at the top of Db.cs.",
                "DriveX", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        Application.Run(new Form1());
    }
}
