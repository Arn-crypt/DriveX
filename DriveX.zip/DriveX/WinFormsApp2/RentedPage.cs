namespace WinFormsApp2;

public partial class RentedPage : UserControl
{
    public RentedPage()
    {
        InitializeComponent();
        Ui.StyleGrid(dgvRentals);
        LoadRentals();
    }

    private void LoadRentals()
    {
        var dt = Db.Query(@"
SELECT r.Id, v.Make + ' ' + v.Model AS Vehicle, r.CustomerName AS Customer, r.Phone,
       r.StartDate AS [Start], r.EndDate AS [End], r.TotalAmount AS Total,
       CASE WHEN r.EndDate < CAST(GETDATE() AS DATE) THEN 'Overdue' ELSE 'Active' END AS Status
FROM dbo.Rentals r
JOIN dbo.Vehicles v ON v.Id = r.VehicleId
WHERE r.IsReturned = 0
ORDER BY r.EndDate");

        dgvRentals.DataSource = dt;
        dgvRentals.Columns["Id"].Visible = false;
        Ui.MoneyColumn(dgvRentals, "Total");
        Ui.DateColumn(dgvRentals, "Start");
        Ui.DateColumn(dgvRentals, "End");

        foreach (DataGridViewRow row in dgvRentals.Rows)
        {
            if (row.Cells["Status"].Value?.ToString() == "Overdue")
                row.DefaultCellStyle.ForeColor = Color.Firebrick;
        }
        lblCount.Text = dt.Rows.Count + " currently rented";
    }

    private void btnReturn_Click(object sender, EventArgs e)
    {
        if (dgvRentals.CurrentRow == null)
        {
            Ui.Warn("Select a rental first.");
            return;
        }
        if (!Ui.Confirm("Mark this car as returned?")) return;

        int id = (int)dgvRentals.CurrentRow.Cells["Id"].Value;
        Db.Execute(@"
SET XACT_ABORT ON;
BEGIN TRAN;
UPDATE dbo.Vehicles SET IsRented = 0
WHERE Id = (SELECT VehicleId FROM dbo.Rentals WHERE Id = @id);
UPDATE dbo.Rentals SET IsReturned = 1 WHERE Id = @id;
COMMIT;", Db.P("@id", id));

        LoadRentals();
    }
}
