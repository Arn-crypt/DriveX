namespace WinFormsApp2;

public partial class HistoryPage : UserControl
{
    public HistoryPage()
    {
        InitializeComponent();
        Ui.StyleGrid(dgvHistory);
        LoadHistory();
    }

    private void LoadHistory()
    {
        var dt = Db.Query(@"
SELECT r.Id AS [Ref #], v.Make + ' ' + v.Model AS Vehicle, r.CustomerName AS Customer,
       r.StartDate AS [Start], r.EndDate AS [End], r.TotalAmount AS Total,
       r.BookedOn AS [Booked On],
       CASE WHEN r.IsReturned = 1 THEN 'Returned' ELSE 'Active' END AS Status
FROM dbo.Rentals r
JOIN dbo.Vehicles v ON v.Id = r.VehicleId
WHERE (v.Make + ' ' + v.Model) LIKE @s OR r.CustomerName LIKE @s
ORDER BY r.Id DESC",
            Db.P("@s", "%" + txtSearch.Text.Trim() + "%"));

        dgvHistory.DataSource = dt;
        Ui.MoneyColumn(dgvHistory, "Total");
        Ui.DateColumn(dgvHistory, "Start");
        Ui.DateColumn(dgvHistory, "End");
        Ui.DateColumn(dgvHistory, "Booked On", "MMM dd, yyyy h:mm tt");

        decimal sum = 0;
        foreach (System.Data.DataRow r in dt.Rows) sum += r.Field<decimal>("Total");
        lblTotal.Text = dt.Rows.Count + " bookings  |  Total: " + Ui.Money(sum);
    }

    private void txtSearch_TextChanged(object sender, EventArgs e) => LoadHistory();
}
