namespace WinFormsApp2;

public partial class VehiclesPage : UserControl
{
    private int? _selectedId;

    public VehiclesPage()
    {
        InitializeComponent();
        Ui.StyleGrid(dgvVehicles);
        cboCategory.Items.AddRange(Ui.Categories);
        cboCategory.SelectedIndex = 0;
        LoadVehicles();
        ClearForm();
    }

    private void LoadVehicles()
    {
        var dt = Db.Query(@"
SELECT Id, Make, Model, [Year], Category, DailyRate AS [Daily Rate],
       CASE WHEN IsRented = 1 THEN 'Rented' ELSE 'Available' END AS Status
FROM dbo.Vehicles
ORDER BY Make, Model");
        dgvVehicles.DataSource = dt;
        dgvVehicles.Columns["Id"].Visible = false;
        Ui.MoneyColumn(dgvVehicles, "Daily Rate");
    }

    private void ClearForm()
    {
        _selectedId = null;
        txtMake.Clear();
        txtModel.Clear();
        numYear.Value = DateTime.Today.Year;
        cboCategory.SelectedIndex = 0;
        numRate.Value = 1000;
        dgvVehicles.ClearSelection();
        dgvVehicles.CurrentCell = null;
    }

    private bool ReadInput(out string make, out string model)
    {
        make = txtMake.Text.Trim();
        model = txtModel.Text.Trim();
        if (make.Length == 0 || model.Length == 0)
        {
            Ui.Warn("Please enter both make and model.");
            return false;
        }
        if (numRate.Value <= 0)
        {
            Ui.Warn("Daily rate must be greater than zero.");
            return false;
        }
        return true;
    }

    private void dgvVehicles_SelectionChanged(object sender, EventArgs e)
    {
        if (dgvVehicles.SelectedRows.Count == 0) return;
        var row = dgvVehicles.SelectedRows[0];
        _selectedId = (int)row.Cells["Id"].Value;
        txtMake.Text = row.Cells["Make"].Value.ToString();
        txtModel.Text = row.Cells["Model"].Value.ToString();
        numYear.Value = Convert.ToDecimal(row.Cells["Year"].Value);
        cboCategory.Text = row.Cells["Category"].Value.ToString();
        numRate.Value = Convert.ToDecimal(row.Cells["Daily Rate"].Value);
    }

    private void btnAdd_Click(object sender, EventArgs e)
    {
        if (!ReadInput(out var make, out var model)) return;
        Db.Execute(@"INSERT INTO dbo.Vehicles(Make, Model, [Year], Category, DailyRate)
                     VALUES(@mk, @md, @y, @c, @r)",
            Db.P("@mk", make), Db.P("@md", model), Db.P("@y", (int)numYear.Value),
            Db.P("@c", cboCategory.Text), Db.P("@r", numRate.Value));
        LoadVehicles();
        ClearForm();
    }

    private void btnUpdate_Click(object sender, EventArgs e)
    {
        if (_selectedId == null) { Ui.Warn("Select a vehicle from the list first."); return; }
        if (!ReadInput(out var make, out var model)) return;
        Db.Execute(@"UPDATE dbo.Vehicles
                     SET Make=@mk, Model=@md, [Year]=@y, Category=@c, DailyRate=@r
                     WHERE Id=@id",
            Db.P("@mk", make), Db.P("@md", model), Db.P("@y", (int)numYear.Value),
            Db.P("@c", cboCategory.Text), Db.P("@r", numRate.Value), Db.P("@id", _selectedId.Value));
        LoadVehicles();
        ClearForm();
    }

    private void btnDelete_Click(object sender, EventArgs e)
    {
        if (_selectedId == null) { Ui.Warn("Select a vehicle from the list first."); return; }

        int rentals = Convert.ToInt32(Db.Scalar(
            "SELECT COUNT(*) FROM dbo.Rentals WHERE VehicleId=@id", Db.P("@id", _selectedId.Value)));
        if (rentals > 0)
        {
            Ui.Warn("This vehicle has rental history and can't be deleted.");
            return;
        }
        if (!Ui.Confirm("Delete this vehicle?")) return;

        Db.Execute("DELETE FROM dbo.Vehicles WHERE Id=@id", Db.P("@id", _selectedId.Value));
        LoadVehicles();
        ClearForm();
    }

    private void btnClear_Click(object sender, EventArgs e) => ClearForm();
}
