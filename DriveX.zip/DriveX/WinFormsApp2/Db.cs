using System.Data;
using Microsoft.Data.SqlClient;

namespace WinFormsApp2;

public static class Db
{
    // Change this if you use SQL Express (e.g. @"Server=.\SQLEXPRESS;...") or a full SQL Server instance.
    private const string ServerPart =
        @"Server=(localdb)\MSSQLLocalDB;Integrated Security=true;TrustServerCertificate=true;";

    private const string DbName = "DriveXDb";
    private static readonly string ConnStr = ServerPart + "Database=" + DbName + ";";

    public static SqlParameter P(string name, object value) =>
        new SqlParameter(name, value ?? DBNull.Value);

    /// <summary>Creates the database, tables and sample cars on first run.</summary>
    public static void Init()
    {
        using (var master = new SqlConnection(ServerPart + "Database=master;"))
        {
            master.Open();
            using var cmd = new SqlCommand($"IF DB_ID('{DbName}') IS NULL CREATE DATABASE [{DbName}];", master);
            cmd.ExecuteNonQuery();
        }

        Execute(@"
IF OBJECT_ID('dbo.Vehicles','U') IS NULL
CREATE TABLE dbo.Vehicles(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Make NVARCHAR(50) NOT NULL,
    Model NVARCHAR(50) NOT NULL,
    [Year] INT NOT NULL,
    Category NVARCHAR(30) NOT NULL,
    DailyRate DECIMAL(10,2) NOT NULL,
    IsRented BIT NOT NULL DEFAULT 0
);
IF OBJECT_ID('dbo.Rentals','U') IS NULL
CREATE TABLE dbo.Rentals(
    Id INT IDENTITY(1,1) PRIMARY KEY,
    VehicleId INT NOT NULL REFERENCES dbo.Vehicles(Id),
    CustomerName NVARCHAR(100) NOT NULL,
    Phone NVARCHAR(30) NULL,
    StartDate DATE NOT NULL,
    EndDate DATE NOT NULL,
    TotalAmount DECIMAL(10,2) NOT NULL,
    IsReturned BIT NOT NULL DEFAULT 0,
    BookedOn DATETIME2 NOT NULL DEFAULT SYSDATETIME()
);
IF NOT EXISTS (SELECT 1 FROM dbo.Vehicles)
INSERT INTO dbo.Vehicles(Make, Model, [Year], Category, DailyRate) VALUES
 ('Toyota','Vios',2022,'Sedan',1800),
 ('Honda','City',2021,'Sedan',1900),
 ('Toyota','Fortuner',2023,'SUV',3800),
 ('Mitsubishi','Montero Sport',2022,'SUV',3600),
 ('Suzuki','Celerio',2021,'Hatchback',1300),
 ('Toyota','Hiace',2022,'Van',4200),
 ('Toyota','Hilux',2023,'Pickup',3500),
 ('Nissan','Navara',2021,'Pickup',3200);");
    }

    public static DataTable Query(string sql, params SqlParameter[] ps)
    {
        using var conn = new SqlConnection(ConnStr);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddRange(ps);
        var table = new DataTable();
        using var adapter = new SqlDataAdapter(cmd);
        adapter.Fill(table);
        return table;
    }

    public static int Execute(string sql, params SqlParameter[] ps)
    {
        using var conn = new SqlConnection(ConnStr);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddRange(ps);
        conn.Open();
        return cmd.ExecuteNonQuery();
    }

    public static object Scalar(string sql, params SqlParameter[] ps)
    {
        using var conn = new SqlConnection(ConnStr);
        using var cmd = new SqlCommand(sql, conn);
        cmd.Parameters.AddRange(ps);
        conn.Open();
        return cmd.ExecuteScalar();
    }
}
