using System.Data;

namespace WinFormsApp2;

public partial class BookPage : UserControl
{
    private readonly Form1 _host;

    public BookPage(Form1 host, int? vehicleId)
    {
        _host = host;
        InitializeComponent();

        dtpStart.MinDate = DateTime.Today;
        dtpStart.Value = DateTime.Today;
        dtpEnd.MinDate = DateTime.Today;
        dtpEnd.Value = DateTime.Today.AddDays(1);

        var vehicles = Db.Query(@"
SELECT Id, Make + ' ' + Model + ' (' + CAST([Year] AS NVARCHAR(4)) + ')' AS Name, DailyRate
FROM dbo.Vehicles
WHERE IsRented = 0
ORDER BY Make, Model");

        cboVehicle.DisplayMember = "Name";
        cboVehicle.ValueMember = "Id";
        cboVehicle.DataSource = vehicles;
        if (vehicleId.HasValue) cboVehicle.SelectedValue = vehicleId.Value;
        UpdateSummary();
    }

    private int Days => (dtpEnd.Value.Date - dtpStart.Value.Date).Days;

    private decimal Rate =>
        cboVehicle.SelectedItem is DataRowView drv ? Convert.ToDecimal(drv.Row["DailyRate"]) : 0m;

    private void UpdateSummary()
    {
        if (cboVehicle.SelectedItem == null)
        {
            lblSummary.Text = "No cars are available right now.";
            btnBook.Enabled = false;
            return;
        }
        btnBook.Enabled = true;
        decimal total = Rate * Math.Max(Days, 0);
        lblSummary.Text =
            "Daily rate:   " + Ui.Money(Rate) + "\r\n" +
            "Rental days:  " + Math.Max(Days, 0) + "\r\n\r\n" +
            "Total:  " + Ui.Money(total);
    }

    private void Input_Changed(object sender, EventArgs e) => UpdateSummary();

    private void btnBook_Click(object sender, EventArgs e)
    {
        if (cboVehicle.SelectedValue == null) { Ui.Warn("Choose a car."); return; }
        if (string.IsNullOrWhiteSpace(txtName.Text)) { Ui.Warn("Enter the customer's name."); return; }
        if (Days < 1) { Ui.Warn("The return date must be after the start date."); return; }

        int vehicleId = Convert.ToInt32(cboVehicle.SelectedValue);

        int free = Convert.ToInt32(Db.Scalar(
            "SELECT COUNT(*) FROM dbo.Vehicles WHERE Id=@id AND IsRented=0", Db.P("@id", vehicleId)));
        if (free == 0) { Ui.Warn("Sorry, that car was just booked."); _host.ShowBook(); return; }

        decimal total = Rate * Days;
        string phone = string.IsNullOrWhiteSpace(txtPhone.Text) ? null : txtPhone.Text.Trim();

        Db.Execute(@"
SET XACT_ABORT ON;
BEGIN TRAN;
INSERT INTO dbo.Rentals(VehicleId, CustomerName, Phone, StartDate, EndDate, TotalAmount)
VALUES(@v, @n, @p, @s, @e, @t);
UPDATE dbo.Vehicles SET IsRented = 1 WHERE Id = @v;
COMMIT;",
            Db.P("@v", vehicleId), Db.P("@n", txtName.Text.Trim()), Db.P("@p", phone),
            Db.P("@s", dtpStart.Value.Date), Db.P("@e", dtpEnd.Value.Date), Db.P("@t", total));

        Ui.Info("Booked! Total: " + Ui.Money(total));
        _host.ShowRented();
    }
}
