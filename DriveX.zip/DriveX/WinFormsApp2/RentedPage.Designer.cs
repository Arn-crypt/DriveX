namespace WinFormsApp2;

partial class RentedPage
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        lblCount = new Label();
        btnReturn = new Button();
        dgvRentals = new DataGridView();
        ((System.ComponentModel.ISupportInitialize)dgvRentals).BeginInit();
        SuspendLayout();
        //
        // lblTitle
        //
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitle.Location = new Point(18, 12);
        lblTitle.Name = "lblTitle";
        lblTitle.Text = "Rented cars";
        //
        // lblCount
        //
        lblCount.AutoSize = true;
        lblCount.Font = new Font("Segoe UI", 10F);
        lblCount.Location = new Point(160, 20);
        lblCount.Name = "lblCount";
        //
        // btnReturn
        //
        btnReturn.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnReturn.BackColor = Color.Black;
        btnReturn.FlatStyle = FlatStyle.Flat;
        btnReturn.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        btnReturn.ForeColor = Color.White;
        btnReturn.Location = new Point(700, 10);
        btnReturn.Name = "btnReturn";
        btnReturn.Size = new Size(160, 32);
        btnReturn.TabIndex = 0;
        btnReturn.Text = "Mark as returned";
        btnReturn.UseVisualStyleBackColor = false;
        btnReturn.Click += btnReturn_Click;
        //
        // dgvRentals
        //
        dgvRentals.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvRentals.Location = new Point(20, 60);
        dgvRentals.Name = "dgvRentals";
        dgvRentals.Size = new Size(840, 350);
        dgvRentals.TabIndex = 1;
        //
        // RentedPage
        //
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.White;
        Controls.Add(dgvRentals);
        Controls.Add(btnReturn);
        Controls.Add(lblCount);
        Controls.Add(lblTitle);
        Name = "RentedPage";
        Size = new Size(880, 428);
        ((System.ComponentModel.ISupportInitialize)dgvRentals).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private Label lblTitle;
    private Label lblCount;
    private Button btnReturn;
    private DataGridView dgvRentals;
}
