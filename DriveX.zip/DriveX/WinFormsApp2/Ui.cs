using System.Globalization;

namespace WinFormsApp2;

public static class Ui
{
    public const string Peso = "\u20B1";
    public static readonly string[] Categories = { "Sedan", "SUV", "Hatchback", "Van", "Pickup" };

    public static string Money(decimal value) =>
        Peso + value.ToString("N2", CultureInfo.InvariantCulture);

    public static void Info(string message) =>
        MessageBox.Show(message, "DriveX", MessageBoxButtons.OK, MessageBoxIcon.Information);

    public static void Warn(string message) =>
        MessageBox.Show(message, "DriveX", MessageBoxButtons.OK, MessageBoxIcon.Warning);

    public static bool Confirm(string message) =>
        MessageBox.Show(message, "DriveX", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes;

    public static void StyleGrid(DataGridView g)
    {
        g.AllowUserToAddRows = false;
        g.AllowUserToDeleteRows = false;
        g.AllowUserToResizeRows = false;
        g.ReadOnly = true;
        g.MultiSelect = false;
        g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        g.RowHeadersVisible = false;
        g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        g.BackgroundColor = Color.White;
        g.BorderStyle = BorderStyle.None;
        g.GridColor = Color.Gainsboro;
        g.EnableHeadersVisualStyles = false;
        g.ColumnHeadersDefaultCellStyle.BackColor = Color.Silver;
        g.ColumnHeadersDefaultCellStyle.ForeColor = Color.Black;
        g.ColumnHeadersDefaultCellStyle.Font = new Font(g.Font, FontStyle.Bold);
        g.DefaultCellStyle.SelectionBackColor = Color.Black;
        g.DefaultCellStyle.SelectionForeColor = Color.White;
        g.RowTemplate.Height = 28;
    }

    public static void MoneyColumn(DataGridView g, string column)
    {
        var style = g.Columns[column].DefaultCellStyle;
        style.Format = "'" + Peso + "'#,##0.00";
        style.Alignment = DataGridViewContentAlignment.MiddleRight;
    }

    public static void DateColumn(DataGridView g, string column, string format = "MMM dd, yyyy") =>
        g.Columns[column].DefaultCellStyle.Format = format;
}
