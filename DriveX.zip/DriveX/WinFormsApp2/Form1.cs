namespace WinFormsApp2;

public partial class Form1 : Form
{
    public Form1()
    {
        InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e) => ShowBrowse();
    private void btnBrowse_Click(object sender, EventArgs e) => ShowBrowse();
    private void btnVehicles_Click(object sender, EventArgs e) => ShowVehicles();
    private void btnBook_Click(object sender, EventArgs e) => ShowBook();
    private void btnRented_Click(object sender, EventArgs e) => ShowRented();
    private void btnHistory_Click(object sender, EventArgs e) => ShowHistory();

    public void ShowBrowse() => ShowPage(new BrowsePage(this), btnBrowse);
    public void ShowVehicles() => ShowPage(new VehiclesPage(), btnVehicles);
    public void ShowBook(int? vehicleId = null) => ShowPage(new BookPage(this, vehicleId), btnBook);
    public void ShowRented() => ShowPage(new RentedPage(), btnRented);
    public void ShowHistory() => ShowPage(new HistoryPage(), btnHistory);

    private void ShowPage(UserControl page, Button active)
    {
        foreach (var b in new[] { btnBrowse, btnVehicles, btnBook, btnRented, btnHistory })
        {
            bool on = b == active;
            b.BackColor = on ? Color.Black : Color.White;
            b.ForeColor = on ? Color.White : Color.Black;
        }

        var old = pnlContent.Controls.Cast<Control>().ToList();
        pnlContent.Controls.Clear();
        foreach (var c in old) c.Dispose();

        page.Dock = DockStyle.Fill;
        pnlContent.Controls.Add(page);
    }
}
