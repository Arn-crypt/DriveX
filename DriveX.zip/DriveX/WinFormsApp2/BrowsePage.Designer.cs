namespace WinFormsApp2;

partial class BrowsePage
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        txtSearch = new TextBox();
        cboCategory = new ComboBox();
        lblCount = new Label();
        btnBook = new Button();
        dgvCars = new DataGridView();
        ((System.ComponentModel.ISupportInitialize)dgvCars).BeginInit();
        SuspendLayout();
        //
        // lblTitle
        //
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitle.Location = new Point(18, 12);
        lblTitle.Name = "lblTitle";
        lblTitle.Text = "Browse available cars";
        //
        // txtSearch
        //
        txtSearch.Font = new Font("Segoe UI", 10F);
        txtSearch.Location = new Point(20, 58);
        txtSearch.Name = "txtSearch";
        txtSearch.PlaceholderText = "Search make or model";
        txtSearch.Size = new Size(250, 25);
        txtSearch.TabIndex = 0;
        txtSearch.TextChanged += Filter_Changed;
        //
        // cboCategory
        //
        cboCategory.DropDownStyle = ComboBoxStyle.DropDownList;
        cboCategory.Font = new Font("Segoe UI", 10F);
        cboCategory.Location = new Point(285, 58);
        cboCategory.Name = "cboCategory";
        cboCategory.Size = new Size(150, 25);
        cboCategory.TabIndex = 1;
        cboCategory.SelectedIndexChanged += Filter_Changed;
        //
        // lblCount
        //
        lblCount.AutoSize = true;
        lblCount.Font = new Font("Segoe UI", 10F);
        lblCount.Location = new Point(450, 62);
        lblCount.Name = "lblCount";
        //
        // btnBook
        //
        btnBook.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnBook.BackColor = Color.Black;
        btnBook.FlatStyle = FlatStyle.Flat;
        btnBook.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        btnBook.ForeColor = Color.White;
        btnBook.Location = new Point(700, 54);
        btnBook.Name = "btnBook";
        btnBook.Size = new Size(160, 32);
        btnBook.TabIndex = 2;
        btnBook.Text = "Book selected car";
        btnBook.UseVisualStyleBackColor = false;
        btnBook.Click += btnBook_Click;
        //
        // dgvCars
        //
        dgvCars.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvCars.Location = new Point(20, 100);
        dgvCars.Name = "dgvCars";
        dgvCars.Size = new Size(840, 310);
        dgvCars.TabIndex = 3;
        //
        // BrowsePage
        //
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.White;
        Controls.Add(dgvCars);
        Controls.Add(btnBook);
        Controls.Add(lblCount);
        Controls.Add(cboCategory);
        Controls.Add(txtSearch);
        Controls.Add(lblTitle);
        Name = "BrowsePage";
        Size = new Size(880, 428);
        ((System.ComponentModel.ISupportInitialize)dgvCars).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private Label lblTitle;
    private TextBox txtSearch;
    private ComboBox cboCategory;
    private Label lblCount;
    private Button btnBook;
    private DataGridView dgvCars;
}
