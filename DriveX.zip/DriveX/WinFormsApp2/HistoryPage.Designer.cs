namespace WinFormsApp2;

partial class HistoryPage
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        txtSearch = new TextBox();
        lblTotal = new Label();
        dgvHistory = new DataGridView();
        ((System.ComponentModel.ISupportInitialize)dgvHistory).BeginInit();
        SuspendLayout();
        //
        // lblTitle
        //
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 14F, FontStyle.Bold);
        lblTitle.Location = new Point(18, 12);
        lblTitle.Name = "lblTitle";
        lblTitle.Text = "Purchase history";
        //
        // txtSearch
        //
        txtSearch.Font = new Font("Segoe UI", 10F);
        txtSearch.Location = new Point(20, 58);
        txtSearch.Name = "txtSearch";
        txtSearch.PlaceholderText = "Search customer or car";
        txtSearch.Size = new Size(280, 25);
        txtSearch.TabIndex = 0;
        txtSearch.TextChanged += txtSearch_TextChanged;
        //
        // lblTotal
        //
        lblTotal.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        lblTotal.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
        lblTotal.Location = new Point(440, 60);
        lblTotal.Name = "lblTotal";
        lblTotal.Size = new Size(420, 24);
        lblTotal.TextAlign = ContentAlignment.MiddleRight;
        //
        // dgvHistory
        //
        dgvHistory.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvHistory.Location = new Point(20, 100);
        dgvHistory.Name = "dgvHistory";
        dgvHistory.Size = new Size(840, 310);
        dgvHistory.TabIndex = 1;
        //
        // HistoryPage
        //
        AutoScaleMode = AutoScaleMode.None;
        BackColor = Color.White;
        Controls.Add(dgvHistory);
        Controls.Add(lblTotal);
        Controls.Add(txtSearch);
        Controls.Add(lblTitle);
        Name = "HistoryPage";
        Size = new Size(880, 428);
        ((System.ComponentModel.ISupportInitialize)dgvHistory).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }

    private Label lblTitle;
    private TextBox txtSearch;
    private Label lblTotal;
    private DataGridView dgvHistory;
}
