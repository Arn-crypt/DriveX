namespace WinFormsApp2;

partial class Form1
{
    private System.ComponentModel.IContainer components = null;

    protected override void Dispose(bool disposing)
    {
        if (disposing && components != null) components.Dispose();
        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        pnlNav = new Panel();
        pnlDivider = new Panel();
        lblLogo = new Label();
        btnBrowse = new Button();
        btnVehicles = new Button();
        btnBook = new Button();
        btnRented = new Button();
        btnHistory = new Button();
        pnlContent = new Panel();
        pnlNav.SuspendLayout();
        SuspendLayout();
        //
        // pnlNav
        //
        pnlNav.BackColor = Color.White;
        pnlNav.Controls.Add(btnHistory);
        pnlNav.Controls.Add(btnRented);
        pnlNav.Controls.Add(btnBook);
        pnlNav.Controls.Add(btnVehicles);
        pnlNav.Controls.Add(btnBrowse);
        pnlNav.Controls.Add(lblLogo);
        pnlNav.Controls.Add(pnlDivider);
        pnlNav.Dock = DockStyle.Top;
        pnlNav.Name = "pnlNav";
        pnlNav.Size = new Size(880, 72);
        pnlNav.TabIndex = 0;
        //
        // pnlDivider
        //
        pnlDivider.BackColor = Color.Gray;
        pnlDivider.Dock = DockStyle.Bottom;
        pnlDivider.Name = "pnlDivider";
        pnlDivider.Size = new Size(880, 1);
        pnlDivider.TabIndex = 6;
        //
        // lblLogo
        //
        lblLogo.BackColor = Color.Silver;
        lblLogo.Font = new Font("Segoe UI", 22F, FontStyle.Bold);
        lblLogo.Location = new Point(0, 13);
        lblLogo.Name = "lblLogo";
        lblLogo.Size = new Size(165, 47);
        lblLogo.TabIndex = 5;
        lblLogo.Text = "DriveX";
        lblLogo.TextAlign = ContentAlignment.MiddleCenter;
        //
        // btnBrowse
        //
        StyleNavButton(btnBrowse, "btnBrowse", "Browse", 180, 118, 0);
        btnBrowse.Click += btnBrowse_Click;
        //
        // btnVehicles
        //
        StyleNavButton(btnVehicles, "btnVehicles", "Vehicles", 304, 118, 1);
        btnVehicles.Click += btnVehicles_Click;
        //
        // btnBook
        //
        StyleNavButton(btnBook, "btnBook", "Book A car", 428, 118, 2);
        btnBook.Click += btnBook_Click;
        //
        // btnRented
        //
        StyleNavButton(btnRented, "btnRented", "Rented cars", 552, 118, 3);
        btnRented.Click += btnRented_Click;
        //
        // btnHistory
        //
        StyleNavButton(btnHistory, "btnHistory", "Purchase History", 676, 162, 4);
        btnHistory.Click += btnHistory_Click;
        //
        // pnlContent
        //
        pnlContent.BackColor = Color.White;
        pnlContent.Dock = DockStyle.Fill;
        pnlContent.Name = "pnlContent";
        pnlContent.TabIndex = 1;
        //
        // Form1
        //
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.White;
        ClientSize = new Size(880, 500);
        Controls.Add(pnlContent);
        Controls.Add(pnlNav);
        MinimumSize = new Size(896, 539);
        Name = "Form1";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "DriveX";
        Load += Form1_Load;
        pnlNav.ResumeLayout(false);
        ResumeLayout(false);
    }

    private static void StyleNavButton(Button b, string name, string text, int x, int width, int tab)
    {
        b.BackColor = Color.White;
        b.FlatAppearance.BorderColor = Color.Black;
        b.FlatAppearance.BorderSize = 1;
        b.FlatStyle = FlatStyle.Flat;
        b.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        b.ForeColor = Color.Black;
        b.Location = new Point(x, 28);
        b.Name = name;
        b.Size = new Size(width, 33);
        b.TabIndex = tab;
        b.Text = text;
        b.UseVisualStyleBackColor = false;
        b.Cursor = Cursors.Hand;
    }

    private Panel pnlNav;
    private Panel pnlDivider;
    private Panel pnlContent;
    private Label lblLogo;
    private Button btnBrowse;
    private Button btnVehicles;
    private Button btnBook;
    private Button btnRented;
    private Button btnHistory;
}
